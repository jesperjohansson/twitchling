const Store = {
  playerURL: undefined,
}

module.exports = Store
